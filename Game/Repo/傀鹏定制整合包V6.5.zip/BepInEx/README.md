# REPO_FPSCounter
A mod for R.E.P.O. that show you FPS Counter.

## Installation

- Install [BepInEx](https://thunderstore.io/c/repo/p/BepInEx/BepInExPack/)
- Unzip this mod into your `REPO/BepInEx` folder

Or use the thunderstore mod manager to handle the installing for you.

## Configuration

- In the BepInEx config folder, you can find com.github.qert2002.REPO_FPSCounter.cfg and set up color and size.