# Colored Nametags
This mod automatically changes the color of the player nametags in-game to match the skin color. It also makes them slightly brighter. Thats it.
### MADE BY @Zombieseatflesh7
### SPECIAL THANKS TO @CharlesE2