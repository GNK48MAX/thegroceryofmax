## v1.0.0 Release 😎
- Adds RGB color sliders to the Select Color page