# TakeyValuables
#### This mod currently adds 2 new valuables. More is planned for the future.

This mod was made for Twitch streamer [Takerst](https://www.twitch.tv/takerst).

## Developer Contact
#### Report bugs, suggest features, or provide feedback:
- **Email:** crithaxxog@gmail.com
- **Twitch:** [CritHaxXoG](https://www.twitch.tv/crithaxxog)
- **YouTube:** [Zehs](https://www.youtube.com/channel/UCb4VEkc-_im0h8DKXlwmIAA)

[![kofi](https://i.imgur.com/jzwECeF.png)](https://ko-fi.com/zehsteam)

## Screenshots
<img src="https://i.imgur.com/Xlfqb0M.png" width="100%">
<img src="https://i.imgur.com/eM8A0VZ.png" width="100%">