# v1.1.0
- Added [REPOLib](https://thunderstore.io/c/repo/p/Zehs/REPOLib/) as a dependancy.

## v1.0.0
- Initial release.