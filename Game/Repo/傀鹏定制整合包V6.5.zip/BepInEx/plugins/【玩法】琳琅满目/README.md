# More Shop Items
[![GitHub](https://img.shields.io/badge/GitHub-MoreShopItems-brightgreen?style=for-the-badge&logo=GitHub)](https://github.com/InfusedGalaxy/MoreShopItems)
[![Thunderstore Version](https://img.shields.io/thunderstore/v/GalaxyMods/MoreShopItems?style=for-the-badge&logo=thunderstore&logoColor=white)](https://thunderstore.io/c/repo/p/GalaxyMods/MoreShopItems)
[![Thunderstore Downloads](https://img.shields.io/thunderstore/dt/GalaxyMods/MoreShopItems?style=for-the-badge&logo=thunderstore&logoColor=white)](https://thunderstore.io/c/repo/p/GalaxyMods/MoreShopItems)

**Additional shopping shelves with increased shop loot**

## Features
- Increased item spawn rate in the shop.
- Additional shelving for more of each item.

## Bug reports
https://github.com/InfusedGalaxy/MoreShopItems/issues