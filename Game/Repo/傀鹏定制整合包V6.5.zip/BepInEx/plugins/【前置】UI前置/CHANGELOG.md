# v1.0.2
- Fixed label size for toggles

# v1.0.1
- Added option support to sliders
  - Rather than displaying a number, words can be displayed

# v1.0.0 🔥
- Initial release