# Are you tired of losing?
This mod restarts the current level after losing!

## Configuration

Recommended: [REPOConfig](https://thunderstore.io/c/repo/p/nickklmao/REPOConfig/)

`Enabled` - If `true` you'll respawn after losing a round, otherwise the game ends  
`Retry HP` - The health you'll respawn with (default 100)

## Note
- Only the host needs this mod
- The map stays the same but the level will get regenerated