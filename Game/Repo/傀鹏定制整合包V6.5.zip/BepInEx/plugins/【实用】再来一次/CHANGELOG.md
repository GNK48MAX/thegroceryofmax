# v1.0.2
- You can finally respawn at 100 HP :D
  - Configurable with the `Retry HP` setting
- Added config a config option to enable/disable the mod

# v1.0.1
- Added debug logs
- Fixed README

# v1.0.0 🔥
- Initial release