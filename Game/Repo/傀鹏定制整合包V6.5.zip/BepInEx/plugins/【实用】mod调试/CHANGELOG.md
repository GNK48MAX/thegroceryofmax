# v1.1.1
- Fixed saved changes, it wasn't working properly :sad:

# v1.1.0
- Added save changes button
- Moved reset button to the bottom
- Added snapping for the bar indicator
- Fixed spacing between settings
- Fixed text scaling
- Fixed bar indicator from getting stuck when not hovering
- Updated README for developers
- Code refactoring
  - This now runs of `MenuLib`

# v1.0.2
- Updated mod list to reflect mod names rather than assembly names
- Updated README for developers
  - Added support for ConfigEntry<float>

# v1.0.1
- Updated README

# v1.0.0 🔥
- Initial release