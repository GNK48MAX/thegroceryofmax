**Fully configurable Flashlight Brightness with REPOConfig!**

Will increase the Flashlight Brightness. To set the brightness level mid game. Bring up the pause menu -> Click Mods -> Click BetterFlashlightMod -> Set the Intensity Slider -> Save Changes -> Close the Pause Menu -> Crouch to disable light -> Then uncrouch to reenable the light with new setting.