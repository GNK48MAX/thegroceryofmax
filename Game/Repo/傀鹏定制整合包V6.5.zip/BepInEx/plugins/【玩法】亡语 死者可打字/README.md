# DeadTTS

Allows you to hear TTS from dead players.<br>
TTS audio from dead players are directional, but can be configured to play in your head.<br>
TTS text will appear near dead players' heads.<br><br>

This mod should not allow dead players to alert monsters, but if it does, please let me know on the mod's github page.