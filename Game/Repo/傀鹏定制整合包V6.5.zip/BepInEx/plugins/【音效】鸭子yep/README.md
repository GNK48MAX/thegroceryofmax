# Yippee Duck
Replaces the quack sounds for the duck with YIPPEE!!!