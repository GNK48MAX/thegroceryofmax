This mod will show total value of the valuables on the map and update in real-time as things break. Current position is the right hand side of the screen a little below the extraction goal.

NOTE: Only host will see value of spawned items (tax return, enemy orbs) added. All players should see the starting value and real-time breaks and extracted value.

Is ALWAYS ON by default and can be configured to be only enabled when map value is at a certain ratio compared to the extraction goal value.

EXAMPLE: Configure 'ValueRatio' to 2.0 to have it appear when remaining map value is 2x the current extraction goal.