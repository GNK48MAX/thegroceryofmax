# Player Count
See how many people are in the current lobby/game!

## Credit
- **yoi02604** icon & mod idea