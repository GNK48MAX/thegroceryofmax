# Description
Use a Health Pack and your friends will also get HP.

# How to use
## Just use the Health Pack.

## CREDITS
My Github Profile [Lowliie](https://github.com/lolipopkungz).
