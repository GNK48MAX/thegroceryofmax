# Pokeball Valuables
### Author: DiscipleShadow
### Version: 1.1.0

#### This mod adds Pokeballs as a valuable item to the game.

##### Join the Discord: https://discord.gg/UAxtQVu3kW
##### Support me at: https://ko-fi.com/discipleshadow
