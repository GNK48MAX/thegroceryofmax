<strong>Removes bullet spread from all firearms!</strong><br>



With Mod

https://i.imgur.com/c99I2FS.mp4

Without Mod

https://i.imgur.com/gdh5GuW.mp4