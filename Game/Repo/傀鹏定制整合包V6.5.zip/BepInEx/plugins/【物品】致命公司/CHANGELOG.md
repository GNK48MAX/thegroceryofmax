# v1.1.1
- Updated valuables properties.
- Fixed Metal Sheet collision.
- Added interaction to Brass Bell and Gift Box valuables.

## v1.1.0
- Updated valuables properties.
- Added 8 new valuables:
  - Fancy Lamp
  - Flask
  - Gift Box
  - Golden Cup
  - Plastic Fish
  - Tea Kettle
  - Teeth
  - V-Type Engine

## v1.0.0
- Initial release.