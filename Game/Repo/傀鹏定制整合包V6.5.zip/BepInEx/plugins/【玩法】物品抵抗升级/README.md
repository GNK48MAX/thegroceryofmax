# ItemResistUpgrade
Adds an upgrade to add item resistance while holding an Item.
Fragile items will be able to withstand a few hits easier!

## Configuration
- **ItemResistUpgradePower**: The multiplier of item resist per upgrade on an item (Lower is stronger)

More Configurations for upgrade pricing, team use, etc, can be found in the [MoreUpgradesMod](https://thunderstore.io/c/repo/p/BULLETBOT/MoreUpgrades/) config