Version 1.2.4 -> 1.3.1

- Added Mage class and 5 new spell for it
- Changed colors of some classes to fit the game more
- Fixed Strongman and Gambler not being stronger
- Fixed multiple minor bugs
- You can now edit all keybinds in the config file (.../BepInEx/config)
- Added textures for the new mana system, these are stored in the assets folder so do not delete that