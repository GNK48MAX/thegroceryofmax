# Big Nukes!

Adds a nuke as a valuable.