Disables self-damage when hitting an enemy with tumble launch or while being in tumble so you can use yourself or your friend as a weapon. :)

Maybe I'll add some more features in the future.