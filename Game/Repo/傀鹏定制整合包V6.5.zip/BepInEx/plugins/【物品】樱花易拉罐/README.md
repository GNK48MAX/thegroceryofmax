Adds different canned drinks to the game as low value items. 

Valuable Can Arizona Cherry
Valuable Can Arizona Green
Valuable Can Cerveza
Valuable Can Crystal Pepsi
Valuable Can Monster
Valuable Can Monster Pink
Valuable Can Monster Doctor
Valuable Can Monster White
Valuable Can RedBull
Valuable Can Vista

If anyone has a request, feel free to ask! :3