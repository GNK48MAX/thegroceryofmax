This mod is great for streamers whose chat constantly asks which level they're on.

While in a level, adds text beneath the extraction counter with the level number.
While in the shop, the text appears beneath the energy counter.