# Description
You can now revive your friends but at the cost of your hp.


# How to use
## You simply grab the head of your dead friend and press the H button or the button you set to revive your friend.

## Configuration

- `StaminaCost`
    - Default : `20`
    - Desc : `The amount of hp consumed when reviving.`
- `ReviveKey`
    - Default : `h`
    - Desc : `The key used to trigger a revive.`

## CREDITS
My Github Profile [Lowliie](https://github.com/lolipopkungz).
