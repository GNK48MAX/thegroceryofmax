# Lethal Plushies!

### Wanna see lethal company enemies in this game? 
#### With this awesome mod you can do so

# All Plushies!

- Hoarding Bug
- Ghost Girl
- Baboon Hawk
- ADDING MORE!!!!!