# ExtractionPointConfirmButton
#### Adds a confirm button to extraction points.

## Developer Contact
#### Report bugs, suggest features, or provide feedback:

| **Discord Server** | **Forum** | **Post** |  
|--------------------|-----------|----------|  
| [R.E.P.O. Modding Server](https://discord.com/invite/vPJtKhYAFe) | `#released-mods` | [ExtractionPointConfirmButton](https://discord.com/channels/1344557689979670578/1346414981351997451) |

- **Email:** crithaxxog@gmail.com
- **Twitch:** [CritHaxXoG](https://www.twitch.tv/crithaxxog)
- **YouTube:** [Zehs](https://www.youtube.com/channel/UCb4VEkc-_im0h8DKXlwmIAA)

[![kofi](https://i.imgur.com/jzwECeF.png)](https://ko-fi.com/zehsteam)

## Screenshots
<img src="https://i.imgur.com/0NHDPtu.png" width="100%">
<img src="https://i.imgur.com/KI5ONyl.gif" width="100%">