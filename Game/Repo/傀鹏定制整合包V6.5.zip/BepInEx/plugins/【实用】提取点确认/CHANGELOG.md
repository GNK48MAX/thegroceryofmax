# v1.0.1
- Fixed soft lock when extracting and your valuable breaks to where you no longer have enough to extract.

## v1.0.0
- Initial release.