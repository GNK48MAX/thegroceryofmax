# XH_DamageShow&EnemyHealthBar v1.0.1
### XiaoHai_REPO_DamageShow&EnemyHealthBar 小海R.E.P.O伤害显示&怪物血条MOD

## Instructions
- Place contents in `bepinex/plugins` folder.  没啥好教的 也没有Config,正常安装正常用即可.

## Changelog
 - v1.0.0
    - Release
 - v1.0.1
    -修复了主客机不同步的问题,之前的版本有时候客机会不显示