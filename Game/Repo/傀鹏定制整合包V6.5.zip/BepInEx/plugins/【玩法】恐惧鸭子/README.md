# Dread Head Duck
Ducks have a chance to spawn with Dread Heads which mimic player's dead heads.

## Settings
- DreadHeadChance: By default, there is a 50% chance for a duck to spawn with a Dread Head. Set to 1 for all ducks to have Dread Heads.
- MimicPlayerHeads: Dread heads will take on the appearance of other player's dead heads. Disabling this will give dread heads a random appearance instead.

The presence and appearance of dread heads will occasionally be desynchronized when clients are configured differently,
so remember to configure the settings before sharing mod-manager codes, or leave them at the default values.

## Bugs / Contact
The fastest way to contact me is via Discord.
You can find me on the R.E.P.O. Modding Discord [DreadHeadDuck Thread](https://discord.com/channels/1344557689979670578/1350019132627615806),
or in my [Deja Drift Discord Server](https://discord.gg/yKwt2AWcGF).
