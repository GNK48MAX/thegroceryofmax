# Improved Stamina

This is a mod that enhances the stamina regeneration system in the game. Instead of the default recharge behavior, this mod introduces a **dynamic stamina regen mechanic**:

#### Default Configuration:
- **Gradual Stamina Regeneration:** After stopping sprinting, stamina starts regenerating after **0.5 seconds**.
- **Scaling Regen Rate:** Over **3.0 seconds**, the regeneration rate increases up to **+8 stamina per second**.
- **More Natural Recovery:** The system ensures a smoother and more responsive stamina recovery experience.

This mod does not alter any other movement mechanics.

---

### Configuration

- You can update the configuration which is located at `BepInEx/config/ImprovedStamina.cfg`

<table>
  <thead>
    <tr>
      <th>Setting</th>
      <th>Default Value</th>
      <th>Description</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td><code>MaxRegenRate</code></td>
      <td>8.0</td>
      <td>The maximum stamina regeneration multiplier.</td>
    </tr>
    <tr>
      <td><code>RegenRampUpTime</code></td>
      <td>3.0</td>
      <td>The time (in seconds) it takes for stamina regeneration to reach max speed.</td>
    </tr>
    <tr>
      <td><code>DelayBeforeRegen</code></td>
      <td>0.5</td>
      <td>The delay (in seconds) after stopping sprinting before regeneration starts.</td>
    </tr>
  </tbody>
</table>