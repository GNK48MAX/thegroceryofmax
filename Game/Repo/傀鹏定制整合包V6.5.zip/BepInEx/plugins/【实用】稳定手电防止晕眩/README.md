# Stable Flashlight
Stabilizes the flashlight to prevent motion sickness.

## Bugs / Contact
The fastest way to contact me is on Discord.
You can find me in the R.E.P.O. Modding Discord server,
or in my [Deja Drift Discord Server](https://discord.gg/yKwt2AWcGF)
