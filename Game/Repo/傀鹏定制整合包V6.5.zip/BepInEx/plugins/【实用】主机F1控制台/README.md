# ItemSpawner

### Wanna spawn items? 
#### With this trash mod you can do so

# Controls
- F1 to open/close menu
- Press tab or pause and click text box to gain focus to the text box
- When done typing left click anywhere to unfocus and press the spawn button or Enter key to spawn item

# Update
- Fixed not working in multiplayer
- Added support for modded items using REPOLib
- Switched way items spawn so names are different [Check Below]

# All Valuables

- Valuable Diamond
- Valuable Emerald Bracelet
- Valuable Goblet
- Valuable Ocarina
- Valuable Pocket Watch
- Valuable Uranium Mug
- Valuable Arctic Bonsai
- Valuable Arctic HDD
- Valuable Chomp Book
- Valuable Crown
- Valuable Doll
- Valuable Frog
- Valuable Gem Box
- Valuable Globe
- Valuable Love Potion
- Valuable Money
- Valuable Music Box
- Valuable Toy Monkey
- Valuable Uranium Plate
- Valuable Vase Small
- Valuable Arctic 3D Printer
- Valuable Arctic Laptop
- Valuable Arctic Propane Tank
- Valuable Arctic Sample
- Valuable Arctic Sample Six Pack
- Valuable Bottle
- Valuable Clown
- Valuable Computer
- Valuable Fan
- Valuable Gramophone
- Valuable Marble Table
- Valuable Radio
- Valuable Ship in a bottle
- Valuable Trophy
- Valuable Vase
- Valuable Wizard Goblin Head
- Valuable Wizard Power Crystal
- Valuable Wizard Time Glass
- Valuable Arctic Barrel
- Valuable Arctic Big Sample
- Valuable Arctic Creature Leg
- Valuable Arctic Flamethrower
- Valuable Arctic Guitar
- Valuable Arctic Sample Cooler
- Valuable Diamond Display
- Valuable Ice Saw
- Valuable Scream Doll
- Valuable Television
- Valuable Vase Big
- Valuable Wizard Cube of Knowledge
- Valuable Wizard Master Potion
- Valuable Animal Crate
- Valuable Arctic Ice Block
- Valuable Dinosaur
- Valuable Piano
- Valuable Wizard Griffin Statue
- Valuable Arctic Science Station
- Valuable Harp
- Valuable Painting
- Valuable Wizard Dumgolfs Staff
- Valuable Wizard Sword
- Valuable Arctic Server Rack
- Valuable Golden Statue
- Valuable Grandfather Clock
- Valuable Wizard Broom
- Enemy - Valuable - Big
- Enemy - Valuable - Medium
- Enemy - Valuable - Small
- Surplus - Valuable - Big
- Surplus - Valuable - Medium
- Surplus - Valuable - Small

# All Items

- Item Cart Medium
- Item Cart Small
- Item Drone Battery
- Item Drone Feather
- Item Drone Indestructible
- Item Drone Torque
- Item Drone Zero Gravity
- Item Extraction Tracker
- Item Grenade Duct Taped
- Item Grenade Explosive
- Item Grenade Human
- Item Grenade Shockwave
- Item Grenade Stun
- Item Gun Handgun
- Item Gun Shotgun
- Item Gun Tranq
- Item Health Pack Large
- Item Health Pack Medium
- Item Health Pack Small
- Item Melee Baseball Bat
- Item Melee Frying Pan
- Item Melee Inflatable Hammer
- Item Melee Sledge Hammer
- Item Melee Sword
- Item Mine Explosive
- Item Mine Shockwave
- Item Mine Stun
- Item Orb Zero Gravity
- Item Power Crystal
- Item Rubber Duck
- Item Upgrade Map Player Count
- Item Upgrade Player Energy
- Item Upgrade Player Extra Jump
- Item Upgrade Player Grab Range
- Item Upgrade Player Grab Strength
- Item Upgrade Player Health
- Item Upgrade Player Sprint Speed
- Item Upgrade Player Tumble Launch
- Item Valuable Tracker