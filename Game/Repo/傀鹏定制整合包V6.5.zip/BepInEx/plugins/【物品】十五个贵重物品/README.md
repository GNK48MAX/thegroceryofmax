# REPOing Valuables
This mod adds 15 new vanilla valuables to R.E.P.O!

## All valuables (file names)

- Arctic Ice Hand
- Broken Fan
- C4
- Cookie
- Engine
- Magic Emerald
- Magic Gnome Statue
- Medium Painting
- Mini Golden Statue
- Pipe
- Ruby
- Skateboard
- Table Bell
- Toilet Paper
- Wine Glass

## Extras

More valuables are expected to come!